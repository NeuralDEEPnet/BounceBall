const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const gravity = 0.5;
const bounce = -10;

let ball = {
  x: canvas.width / 2,
  y: canvas.height / 2,
  radius: 15,
  color: "orange",
  velocityY: 0
};

let isGameOver = false;
let score = 0;
let bestScore = localStorage.getItem("bestScore") || 0;

function drawBall() {
  ctx.beginPath();
  ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
  ctx.fillStyle = ball.color;
  ctx.fill();
  ctx.closePath();
}

function updateBall() {
  ball.velocityY += gravity;
  ball.y += ball.velocityY;

  if (ball.y + ball.radius > canvas.height) {
    isGameOver = true;
  }
}

function drawScore() {
  ctx.fillStyle = "white";
  ctx.font = "18px Arial";
  ctx.fillText("Score: " + score, 10, 30);
  ctx.fillText("Best: " + bestScore, 10, 50);
}

function gameLoop() {
  if (isGameOver) {
    ctx.fillStyle = "white";
    ctx.font = "30px Arial";
    ctx.fillText("Game Over", canvas.width / 2 - 80, canvas.height / 2);
    ctx.font = "20px Arial";
    ctx.fillText("Tap to restart", canvas.width / 2 - 60, canvas.height / 2 + 40);
    if (score > bestScore) {
      localStorage.setItem("bestScore", score);
    }
    return;
  }

  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawBall();
  updateBall();
  drawScore();
  score++;
  requestAnimationFrame(gameLoop);
}

document.addEventListener("keydown", jump);
canvas.addEventListener("click", jump);
canvas.addEventListener("touchstart", jump);

function jump() {
  if (!isGameOver) {
    ball.velocityY = bounce;
  } else {
    resetGame();
  }
}

function resetGame() {
  ball.y = canvas.height / 2;
  ball.velocityY = 0;
  score = 0;
  isGameOver = false;
  gameLoop();
}

gameLoop();